

<?php $__env->startSection('title', 'Identificar focos'); ?>

<?php $__env->startSection('content'); ?>
    <div id="event-create-container" class="col-md-6 offset-md-3">
        <h1>Identificação de focos de dengue</h1>
        <form id="eventoForm" action="/focos" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div class="custom-file">
                    <label for="image">Imagem do foco:</label>
                    <input type="file" id="image" name="image" class="custom-file-input">
                </div>
            </div>
            <div class="form-group">
                <label for="title">Nome do Foco:</label>
                <input type="text" class="form-control" id="title" name="title" placeholder="Dê um nome ao foco">
            </div>
            <div class="form-group">
                <label for="date">Data:</label>
                <input type="date" class="form-control" id="date" name="date" placeholder="Data do foco">
            </div>
            <!-- Campo CEP e Botão para Localizar no Mapa -->
            <div class="form-group">
                <label for="search-cep">Localizar pelo CEP:</label>
                <input type="text" class="form-control" id="search-cep" placeholder="Digite o CEP"
                    style="margin-bottom: 15px;"><br />
                <div style="display: flex; justify-content: center; align-items: center; gap: 5px; margin:15 0 0 0;">
                    <button type="button" class="btn btn-primary"
                         onclick="locateByCep()">Localizar no Mapa</button>
                    <a href="https://buscacepinter.correios.com.br/app/endereco/index.php?t" class="btn btn-link"
                        target="_blank">Não sei o CEP</a>
                </div>
                <br>
            </div>
            <!-- Código do Mapa -->
            <div class="container-mapa text-center">
                <div id="map" style="width: 600px; height: 400px;"></div>
            </div>
            <input type="hidden" id="latitude" name="latitude">
            <input type="hidden" id="longitude" name="longitude">
            <input type="hidden" id="cep" name="cep">
            <input type="hidden" id="city" name="city">
            <input type="hidden" id="state" name="state">
            <input type="hidden" id="endereco" name="endereco">
            <input type="hidden" id="numero" name="numero">

            <div class="form-group half-width">
                <label for="cep">CEP </label>
                <input type="text" class="form-control half-width" id="cep-display" disabled>
            </div>
            <div class="form-group half-width">
                <label for="city">Cidade </label>
                <input type="text" class="form-control half-width" id="city-display" disabled>
            </div>
            <div class="form-group half-width">
                <label for="state">Estado </label>
                <input type="text" class="form-control half-width" id="state-display" disabled>
            </div>
            <div class="form-group half-width">
                <label for="endereco">Endereço </label>
                <input type="text" class="form-control half-width" id="endereco-display" disabled>
            </div>
            <div class="form-group half-width">
                <label for="numero">Número </label>
                <input type="text" class="form-control half-width" id="numero-display" disabled>
            </div>



            <div class="form-group">
                <label for="description">Descrição do foco:</label>
                <textarea id="description" name="description" class="form-control custom-textarea" placeholder="Descrição do foco"></textarea>
            </div>
            <div class="form-group">
                <label for="focos_identificados">Selecione os focos que você identificou na imagem:</label>
            </div>
            <div class="form-group custom-border p-3">
                <div class="form-group">
                    <input type="checkbox" name="items[]" value="pneu">Pneu
                </div>
                <div class="form-group">
                    <input type="checkbox" name="items[]" value="Vaso">Vaso de planta
                </div>
                <div class="form-group">
                    <input type="checkbox" name="items[]" value="Garrafa">Garrafa
                </div>
                <div class="form-group">
                    <input type="checkbox" name="items[]" value="Plastico">Plástico
                </div>
                <div class="form-group">
                    <input type="checkbox" name="items[]" value="caixadagua">Caixa d'água
                </div>
                <div class="form-group">
                    <input type="checkbox" name="items[]" value="Outros">Outros
                </div>
            </div>
            <input type="submit" class="btn btn-primary btn-IdentFoco" name="criar_evento" value="Enviar">
        </form>
    </div>

    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>
        function validateCEP(input) {
            // Remove qualquer caractere que não seja letra, número ou traço e limita a 9 caracteres
            input.value = input.value.replace(/[^a-zA-Z0-9-]/g, '').substring(0, 9);
        }

        var map = L.map('map').setView([51.505, -0.09], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var marker;

        // Função para obter a localização atual do usuário
        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    var lat = position.coords.latitude;
                    var lng = position.coords.longitude;

                    // Centralizar o mapa na localização atual
                    map.setView([lat, lng], 13);

                    // Adicionar um marcador na localização atual
                    if (marker) {
                        map.removeLayer(marker);
                    }
                    marker = L.marker([lat, lng]).addTo(map);
                    marker.bindPopup("Você está aqui!<br>Latitude: " + lat + "<br>Longitude: " + lng).openPopup();

                    document.getElementById('latitude').value = lat;
                    document.getElementById('longitude').value = lng;
                    convertCoordinatesToAddress(lat, lng);
                }, function(error) {
                    console.error("Erro ao obter a localização: " + error.message);
                });
            } else {
                alert("Geolocalização não é suportada pelo seu navegador.");
            }
        }

        // Chamar a função para obter a localização atual do usuário
        getLocation();

        map.on('click', function(e) {
            if (marker) {
                map.removeLayer(marker);
            }
            marker = L.marker([e.latlng.lat, e.latlng.lng]).addTo(map);
            marker.bindPopup("Latitude: " + e.latlng.lat + "<br>Longitude: " + e.latlng.lng).openPopup();

            document.getElementById('latitude').value = e.latlng.lat;
            document.getElementById('longitude').value = e.latlng.lng;
            convertCoordinatesToAddress(e.latlng.lat, e.latlng.lng);
        });

        function convertCoordinatesToAddress(lat, lng) {
            var url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`;

            axios.get(url)
                .then(function(response) {
                    var data = response.data;
                    document.getElementById('cep').value = data.address.postcode || '';
                    document.getElementById('cep-display').value = data.address.postcode || '';
                    document.getElementById('city').value = data.address.city || data.address.town || data.address
                        .village || '';
                    document.getElementById('city-display').value = data.address.city || data.address.town || data
                        .address.village || '';
                    document.getElementById('state').value = data.address.state || '';
                    document.getElementById('state-display').value = data.address.state || '';
                    document.getElementById('endereco').value = data.address.road || '';
                    document.getElementById('endereco-display').value = data.address.road || '';
                    document.getElementById('numero').value = data.address.house_number || '';
                    document.getElementById('numero-display').value = data.address.house_number || '';
                })
                .catch(function(error) {
                    console.error('Erro ao converter coordenadas em endereço:', error);
                });
        }

        function locateByCep() {
            var cep = document.getElementById('search-cep').value;
            if (cep) {
                var url = `https://viacep.com.br/ws/${cep}/json/`;

                axios.get(url)
                    .then(function(response) {
                        var data = response.data;
                        if (!data.erro) {
                            var logradouro = `${data.logradouro}, ${data.localidade}, ${data.uf}`;
                            var nominatimUrl =
                                `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(logradouro)}&format=json&limit=1`;

                            axios.get(nominatimUrl)
                                .then(function(response) {
                                    var location = response.data[0];
                                    if (location) {
                                        var lat = location.lat;
                                        var lng = location.lon;

                                        map.setView([lat, lng], 13);

                                        if (marker) {
                                            map.removeLayer(marker);
                                        }
                                        marker = L.marker([lat, lng]).addTo(map);
                                        marker.bindPopup("Localização encontrada!<br>Latitude: " + lat +
                                            "<br>Longitude: " + lng).openPopup();

                                        document.getElementById('latitude').value = lat;
                                        document.getElementById('longitude').value = lng;
                                        convertCoordinatesToAddress(lat, lng);
                                    } else {
                                        alert("Localização não encontrada.");
                                    }
                                })
                                .catch(function(error) {
                                    console.error('Erro ao converter CEP em coordenadas:', error);
                                });
                        } else {
                            alert("CEP não encontrado.");
                        }
                    })
                    .catch(function(error) {
                        console.error('Erro ao buscar CEP:', error);
                    });
            } else {
                alert("Por favor, insira um CEP.");
            }
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views/focos/identificarFoco.blade.php ENDPATH**/ ?>