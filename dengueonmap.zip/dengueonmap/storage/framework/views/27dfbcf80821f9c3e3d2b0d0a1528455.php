

<?php $__env->startSection('title','Criar eventos'); ?>

<?php $__env->startSection('content'); ?>
<div id="event-create-container" class="col-md-6 offset-md-3">
    <h1>Tela de Criação de eventos</h1>
    <form id="eventoForm" action="/events" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="image">Imagem do evento:</label>
            <input type="file" id="image" name="image" class="form-control-file">
            <small id="imageHelp" class="form-text text-muted" style="color: red; display: none;">A imagem é obrigatória.</small>
        </div>
        <div class="form-group">
            <label for="title">Evento:</label>
            <input type="text" class="form-control" id="title" name="title" 
                placeholder="Nome do evento">
        </div>
        <div class="form-group">
            <label for="date">Data do Evento:</label>
            <input type="date" class="form-control" id="date" name="date" 
                placeholder="Data do evento">
        </div>
        <div class="form-group">
            <label for="title">Cidade:</label>
            <input type="text" class="form-control" id="city" name="city" placeholder="Local do evento">
        </div>
        <div class="form-group">
            <label for="title">CEP</label>
            <input type="text" class="form-control" id="cep" name="cep" placeholder="CEP">
            <a href="https://buscacepinter.correios.com.br/app/endereco/index.php?t" class="btn btn-link"
                        target="_blank">Não sei o CEP</a>
        </div>
        <div class="form-group">
            <label for="title">Endereço</label>
            <input type="text" class="form-control" id="endereco" name="endereco" placeholder="Endereço">
        </div>
        <!--<div class="form-group">
            <label for="title">O evento é privado?</label>
            <select name="private" id="private" class="form-control">
                <option value="0">Não</option>
                <option value="1">Sim</option>
            </select>
        </div> -->
        <div class="form-group">
            <label for="title">Descrição do evento:</label> </br>
            <textarea id="description" name="description" class="form-control" placeholder="Descrição do evento" rows="5" style="width: 100%;"></textarea>
        </div>
        <br>
        <!-- <div class="form-group">
            <label for="title">Adicione eventos de infraestrutura</label>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Cadeiras">Cadeiras
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Palco">Palco
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Cerveja">Cerveja grátis
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Open food">Open food
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="brindes">Brindes
            </div>
        </div>-->
        <input type="submit" class="btn btn-primary" name="criar_evento" value="criar evento">

        <br><br>

    </form>
   </div>

   <script>
    function validateForm() {
        const imageInput = document.getElementById('image');
        const imageHelp = document.getElementById('imageHelp');

        if (imageInput.files.length === 0) {
            imageHelp.style.display = 'block';
            return false;
        } else {
            imageHelp.style.display = 'none';
            return true;
        }
    }

    const cepInput = document.getElementById('cep');
    const enderecoInput = document.getElementById('endereco');

    cepInput.addEventListener('change', function() {
        const cep = cepInput.value;

        fetch(`/buscarCep/${cep}`)
            .then(response => response.json())
            .then(data => {
                enderecoInput.value = data.logradouro + ', ' + data.bairro + ', '
                     + data.localidade + ' - ' + data.uf;
            })
            .catch(error => {
                console.error('Erro ao buscar CEP:', error);
            });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views/events/create.blade.php ENDPATH**/ ?>