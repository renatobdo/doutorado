@extends('layouts.main')

@section('title', 'Página Inicial')

@section('content')
    <div class="col-6 col-md-2 col-xxl-2 text-center">
        <!-- <img src="/img/animated.gif" alt="Animação" class="img-fluid"> -->
    </div>
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    @if (session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif
    <div class="row">
        <div class="col-md-10">
            <div class="container-mapa text-center">
                <label for="cep" style="color:#17882c; padding:10px;">Localizar pelo CEP:</label>
                <input type="text" class="form-control half-width" id="cep" name="cep" placeholder="01234-567"
                    value="12345678" oninput="validateCEP(this)" style="display: inline-block; width:25%"><br />

                <div style="display: flex; justify-content: center; align-items: center; gap: 10px; margin: 40px">
                    <button type="button" class="btn btn-primary" onclick="locateByCep()">Localizar</button>
                    <a href="https://buscacepinter.correios.com.br/app/endereco/index.php?t" class="btn btn-link"
                        target="_blank">Não sei o CEP</a>
                </div>
                <br><br>

                <!-- Código do Mapa 
                <div id="map" style="width: 600px; height: 400px; margin: 0 auto;"></div>-->
                <!-- Código do Mapa -->
                <div id="map" class="responsive-map"></div>
            </div>
        </div>
        <div class="col-md-5 titulo" style="width: 10%;">
            <h2>Ranking</h2>
            <ul class="list-group">
                @foreach ($rankingUsuarios as $usuario)
                    @php

                        $emailPrefix = explode('@', $usuario->email)[0];
                    @endphp
                    <!--<li class="list-group-item d-flex justify-content-between align-items-center">-->
                    {{ $loop->iteration }}.{{ $emailPrefix }}
                    <span class="badge badge-primary badge-pill">{{ $usuario->focos_count }}</span>
                    <!--</li>-->
                @endforeach
            </ul>
        </div>

    </div>
    <div id="focos-container">
        <h2>Focos recentes</h2>
        <p class="subtitle">Veja os focos da dengue identificados pelos cidadãos recentemente</p>

        <div class="container row mx-auto g-4">
            @foreach ($focosRecentes as $foco)
                <div class="col-6 col-md-3 col-xxl-2">
                    <div class="card">
                        <img src="{{ $foco->caminho_foto }}" alt="{{ $foco->nome_foco }}" class="card-img-top">

                        <div class="card-body">
                            <p class="card-date">{{ date('d/m/Y', strtotime($foco->data_foco)) }}</p>
                            <h5 class="card-title">{{ $foco->nome_foco }}</h5>
                            <p class="card-text">{{ Str::limit($foco->descricao, 22, '...') }}</p>
                            @php

                                $nomeUsuario = explode(' ', $foco->user->name)[0];
                            @endphp
                            <p class="card-text">Identificado por: {{ $nomeUsuario }}</p>
                            <a href="/focos/{{ $foco->id }}" class="btn btn-primary">Saber mais</a>
                        </div>
                    </div>
                </div>
            @endforeach

            @if (count($focosRecentes) == 0)
                <p>Não há focos disponíveis</p>
            @endif
        </div>
    </div>
    <div id="events-container">
        <h2>Eventos</h2>
        <p class="subtitle">Veja os eventos de combate às arboviroses</p>

        <div class="container row mx-auto g-4">
            @foreach ($eventosRecentes as $evento)
                <div class="col-6 col-md-3 col-xxl-2">
                    <div class="card">
                        <img src="img/events/{{ $evento->image }}" alt="{{ $evento->titulo }}" class="card-img-top">

                        <div class="card-body">
                            <p class="card-date">{{ date('d/m/Y', strtotime($evento->date)) }}</p>
                            <h5 class="card-title">{{ $evento->titulo }}</h5>
                            <p class="card-text">{{ Str::limit($evento->descricao, 22, '...') }}</p>
                            @php

                                $nomeUsuario = explode(' ', $foco->user->name)[0];
                            @endphp
                            <p class="card-text">Criado por: {{ $nomeUsuario }}</p>

                            <a href="/events/{{ $evento->id }}" class="btn btn-primary">Saber mais</a>
                        </div>
                    </div>
                </div>
            @endforeach

            @if (count($eventosRecentes) == 0)
                <p>Não há eventos disponíveis</p>
            @endif
        </div>
    </div>


    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>
        var map;
        var userMarker;
        var userCircle;
        var focoMarkers = [];

        function initializeMap(latLng) {
            map = L.map('map').setView(latLng, 13);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);

            userMarker = L.marker(latLng).addTo(map)
                .bindPopup("<strong>Você está aqui!</strong><br>Latitude: " + latLng[0] + "<br>Longitude: " + latLng[1])
                .openPopup();

            userCircle = L.circle(latLng, {
                color: 'blue',
                fillColor: 'blue',
                fillOpacity: 0.2,
                radius: 500 // 500 metros de raio
            }).addTo(map);

            locateByUserPosition(latLng);
        }

        function locateByUserPosition(latLng) {
            console.log(`Buscando focos próximos de Latitude: ${latLng[0]}, Longitude: ${latLng[1]}`);
            axios.get(`/buscarFocosProximos?lat=${latLng[0]}&lng=${latLng[1]}`)
                .then(response => {
                    console.log('Resposta da API:', response.data);
                    const focos = response.data;
                    focos.forEach(foco => {
                        const focoLatLng = [foco.latitude, foco.longitude];
                        const marker = L.marker(focoLatLng).addTo(map)
                            .bindPopup(
                                `<strong>Latitude:</strong> ${foco.latitude}<br><strong>Longitude:</strong> ${foco.longitude}<br><strong>Probabilidade de contrair dengue: </strong>Alta<br><strong>Recomendação:</strong> utilizar repelente`
                            );
                        focoMarkers.push(marker);
                    });
                })
                .catch(error => {
                    console.error('Erro ao buscar focos próximos:', error);
                });
        }

        function locateByCep() {
            const cep = document.getElementById('cep').value;
            const urlOpenStreetMap =
                `https://nominatim.openstreetmap.org/search?format=json&postalcode=${cep}&country=Brazil`;

            fetch(urlOpenStreetMap)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        const lat = parseFloat(data[0].lat);
                        const lon = parseFloat(data[0].lon);
                        const latLng = [lat, lon];

                        map.setView(latLng, 13);
                        userMarker.setLatLng(latLng)
                            .setPopupContent("Localizado pelo CEP!<br>Latitude: " + lat + "<br>Longitude: " + lon)
                            .openPopup();

                        if (userCircle) {
                            map.removeLayer(userCircle);
                        }
                        userCircle = L.circle(latLng, {
                            color: 'blue',
                            fillColor: 'blue',
                            fillOpacity: 0.2,
                            radius: 500 // 500 metros de raio
                        }).addTo(map);

                        focoMarkers.forEach(marker => map.removeLayer(marker));
                        focoMarkers = [];
                        locateByUserPosition(latLng);
                    } else {
                        locateByCepViaCep(cep);
                    }
                })
                .catch(error => {
                    console.error('Erro ao buscar CEP no OpenStreetMap:', error);
                    locateByCepViaCep(cep);
                });
        }

        function locateByCepViaCep(cep) {
            const urlViaCep = `https://viacep.com.br/ws/${cep}/json/`;

            fetch(urlViaCep)
                .then(response => response.json())
                .then(data => {
                    if (data.erro) {
                        alert('CEP não encontrado.');
                    } else {
                        const logradouro = data.logradouro;
                        const localidade = data.localidade;
                        const uf = data.uf;

                        const query = `${logradouro}, ${localidade}, ${uf}, Brazil`;
                        locateByAddress(query);
                    }
                })
                .catch(error => console.error('Erro ao buscar CEP no ViaCEP:', error));
        }

        function locateByAddress(query) {
            const urlOpenStreetMap =
                `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`;

            fetch(urlOpenStreetMap)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        const lat = parseFloat(data[0].lat);
                        const lon = parseFloat(data[0].lon);
                        const latLng = [lat, lon];

                        map.setView(latLng, 13);
                        userMarker.setLatLng(latLng)
                            .setPopupContent("Localizado pelo endereço!<br>Latitude: " + lat + "<br>Longitude: " + lon)
                            .openPopup();

                        if (userCircle) {
                            map.removeLayer(userCircle);
                        }
                        userCircle = L.circle(latLng, {
                            color: 'blue',
                            fillColor: 'blue',
                            fillOpacity: 0.2,
                            radius: 500 // 500 metros de raio
                        }).addTo(map);

                        focoMarkers.forEach(marker => map.removeLayer(marker));
                        focoMarkers = [];
                        locateByUserPosition(latLng);
                    } else {
                        alert('Endereço não encontrado no OpenStreetMap.');
                    }
                })
                .catch(error => console.error('Erro ao buscar endereço no OpenStreetMap:', error));
        }

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                const latLng = [position.coords.latitude, position.coords.longitude];
                initializeMap(latLng);
            }, error => {
                console.error('Erro ao obter localização:', error);
                const defaultLatLng = [-23.5505, -46.6333]; // São Paulo, por exemplo
                initializeMap(defaultLatLng);
            });
        } else {
            console.log("Geolocalização não é suportada pelo navegador.");
            const defaultLatLng = [-23.5505, -46.6333]; // São Paulo, por exemplo
            initializeMap(defaultLatLng);
        }

        // Script para ocultar as mensagens de sucesso/erro após alguns segundos
        document.addEventListener("DOMContentLoaded", function() {
            setTimeout(function() {
                var alertSuccess = document.querySelector('.alert-success');
                var alertDanger = document.querySelector('.alert-danger');
                if (alertSuccess) {
                    alertSuccess.classList.add('alert-hide');
                }
                if (alertDanger) {
                    alertDanger.classList.add('alert-hide');
                }
            }, 5000); // 5000 milissegundos = 5 segundos
        });

        function validateCEP(input) {
            // Remove qualquer caractere que não seja letra, número ou traço e limita a 9 caracteres
            input.value = input.value.replace(/[^a-zA-Z0-9-]/g, '').substring(0, 9);
        }
    </script>
@endsection
