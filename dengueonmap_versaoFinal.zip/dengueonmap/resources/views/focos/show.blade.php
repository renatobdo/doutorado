@extends('layouts.main')

@section('title', $foco->nome_foco)

@section('content')
    <div class="col-md-10 offset-md-1">
        <div class="row">
            <div id="image-container" class="col-md-6">

                <img src="{{ '../' . $foco->caminho_foto }}" alt="{{ $foco->nome_foco }}" class="img-fluid">
            </div>
            <div id="info-container" class="col-md-6">
                <h1>{{ $foco->nome_foco }}</h1>
                <p class="card-date">{{ date('d/m/Y', strtotime($foco->data_foco)) }}</p>
                <p class="card-text">{{ $foco->descricao }}</p>
                <p class="card-text">Identificado por: {{ $focoOwner['name'] }}</p>

                
                    @if ($hasUserIdentified)
                        <p>Você identificou este foco.</p>
                    @else
                        <form action="{{ route('focos.join', ['id' => $foco->id]) }}" method="POST">
                            @csrf
                            <button type="submit" class="btn btn-primary">Monitorar foco</button>
                        </form>
                    @endif
               
            </div>
        </div>
    </div>
@endsection
