@extends('layouts.main')

@section('title', 'Dashboard de Focos')

@section('content')

<div class="col-md-10 offset-md-1 dashboard-title-container"><h1>Meus Focos</h1></div>
<div class="col-md-10 offset-md-1 dashboard-events-container">
    @if(count($focosIdentificados) > 0)
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>
           @foreach($focosIdentificados as $foco)
           <tr>
               <td scope="row">{{ $loop->index + 1 }}</td>
               <td><a href="/focos/{{ $foco->id }}">{{ $foco->nome_foco }}</a></td>
               <td>
                    <a href="/focos/edit/{{ $foco->id }}" class="btn btn-info edit-btn">
                        <ion-icon name="create-outline"></ion-icon>Editar
                    </a>
                    <form action="/focos/{{ $foco->id }}" method="POST" style="display:inline-block;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger delete-btn">
                            <ion-icon name="trash-outline"></ion-icon>Deletar
                        </button>
                    </form>
                </td>
           </tr>
           @endforeach
       </tbody>
    </table>
    @else
    <p>Você ainda não identificou nenhum foco, <a href="/focos/create">identificar foco</a></p>
    @endif
</div>
<div class="col-md-10 offset-md-1 dashboard-title-container"><h1>Focos que estou monitorando</h1></div>
<div class="col-md-10 offset-md-1 dashboard-events-container">
    @if(count($focosMonitorados) > 0)
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>
           @foreach($focosMonitorados as $foco)
           <tr>
               <td scope="row">{{ $loop->index + 1 }}</td>
               <td><a href="/focos/{{ $foco->id }}">{{ $foco->nome_foco }}</a></td>
               <td>
                    <form action="/focos/unmonitor/{{ $foco->id }}" method="POST" style="display:inline-block;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger delete-btn">
                            <ion-icon name="trash-outline"></ion-icon>Deixar de Monitorar
                        </button>
                    </form>
                </td>
           </tr>
           @endforeach
       </tbody>
    </table>
    @else
    <p>Você ainda não está monitorando nenhum foco, <a href="/">veja todos os focos</a></p>
    @endif
</div>

@endsection
