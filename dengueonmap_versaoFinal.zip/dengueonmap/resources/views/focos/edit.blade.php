@extends('layouts.main')

@section('title', 'Editar focos: '.$foco->nome_foco)

@section('content')
<div id="foco-create-container" class="col-md-6 offset-md-3">
    <h1>Editando: {{$foco->nome_foco}}</h1>
    <form id="focoForm" action="/focos/update/{{$foco->id}}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="image">Imagem do foco:</label>
            <input type="file" id="image" name="image" class="form-control-file">
            <img src="/{{ $foco->caminho_foto }}" alt="{{$foco->nome_foco}}" class="img-preview">
        </div>
        <div class="form-group">
            <label for="title">Nome do Foco:</label>
            <input type="text" class="form-control" id="nome_foco" name="nome_foco" placeholder="Nome do foco" value="{{$foco->nome_foco}}">
        </div>
        <div class="form-group">
            <label for="date">Data do Foco:</label>
            <input type="date" class="form-control" id="data_foco" name="data_foco" value="{{ date('Y-m-d', strtotime($foco->data_foco)) }}">
        </div>
        <div class="form-group">
            <label for="cidade">Cidade:</label>
            <input type="text" class="form-control" id="cidade" name="cidade" placeholder="Local do foco" value="{{$foco->cidade}}">
        </div>
        <div class="form-group">
            <label for="descricao">Descrição do Foco:</label>
            <textarea id="descricao" name="descricao" class="form-control" placeholder="Descrição do foco">{{$foco->descricao}}</textarea>
        </div>
        <br>
        <div class="form-group">
            <label for="focos_identificados">Adicione focos identificados</label>
            @php
                $items = json_decode($foco->focos_identificados, true) ?? [];
            @endphp
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Pneu" {{ in_array('Pneu', $items) ? 'checked' : '' }}>Pneu
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Vaso" {{ in_array('Vaso', $items) ? 'checked' : '' }}>Vaso de planta
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Garrafa" {{ in_array('Garrafa', $items) ? 'checked' : '' }}>Garrafa
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Plástico" {{ in_array('Plástico', $items) ? 'checked' : '' }}>Plástico
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Caixa d'água" {{ in_array("Caixa d'água", $items) ? 'checked' : '' }}>Caixa d'água
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Outros" {{ in_array('Outros', $items) ? 'checked' : '' }}>Outros
            </div>
        </div>
        <input type="submit" class="btn btn-primary" value="Editar Foco">
        <br><br>
    </form>
</div>
@endsection
