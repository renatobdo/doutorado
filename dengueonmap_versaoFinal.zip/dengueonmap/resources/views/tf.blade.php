
@extends('layouts.main')

@section('title', 'Página de trabalhos futuros sobre arboviroses')

@section('content')


<div id="tf-container" class="clearfix">
    <h1>Página de trabalhos futuros sobre arboviroses</h1><br><br>
      
    <a href="https://www.w3.org/Translations/DWBP-pt-BR/#bestPractices">
        Clique aqui para ler as boas práticas de dados na web</a><br><br>
        <a href="https://blog.dsacademy.com.br/as-6-dimensoes-da-qualidade-de-dados-data-quality/">
            Clique aqui para ler sobre agrupamento de dados</a><br><br>
            <a href="https://blog.dsacademy.com.br/as-6-dimensoes-da-qualidade-de-dados-data-quality/">
                Clique aqui para ler sobre pipeline de dados</a>
                <br><br>
            <a href='#'>gamificação</a>
                    <br><br>
                <ul>
                    <li>A clusterização, ou agrupamento de dados, é uma técnica que
                         busca identificar grupos de objetos semelhantes em um conjunto
                          de dados, com base em suas características, permitindo uma melhor
                           compreensão dos dados e a descoberta de insights relevantes </li><br>
                    <li>Dê uma olhada no K-Means</li><br>
                    <li>Por que em alguns municípios a incidência é maior de arboviroses do que em outras? Veja a distribuição 
                        de dados para tentar entender (normal, right skewed, left skewed). Alguns municípios
                    recebem mais verbas ou possuem mais escolaridade e camapanhas de prevenção? Tentar estabelecer
                correlações...</li><br>
                <li>Será que eu poderia adotar uma estratégia de gestão de metadados para acelerar o processo de integração de dados?
                    Veja a inspiração da transformação digital em: https://plataforma.rede.gov.br/ 
                <ul>
                    <li>Diagnóstico e análise situacional - Compreender a situação atual de sua cidade e comparar-se com outros municípios
                    </li>
                    <li>Elaboração de planos e projetos de gestão de metadados - Acesso a soluções baseadas em boas práticas e aderentes aos desafios do seu município</li>
                    <li>Aceleração do processo de gestão de metadados</li>
                </ul>
            </ul>
            <p> extração de dados de fontes diversas como vídeos </p>
            <p> Detecção de fake news: https://nilc-fakenews.herokuapp.com/ </p>
            <p> Informações que podem ser obtidas de vídeos: </p>
            <ul>
                <li>Remédios que  não podem ser tomados
                </li>
                <li>Por que as crianças de 10 a 14 anos estão recebendo vacina antes dos idosos? Por que é a faixa etária que mais evolui para a forma grave da doença</li>
                <li>Os ovos do mosquito da dengue podem sobreviver por 1 ano. Por isso, é importante tirar água parada dos vazos de plantas</li>
            </ul>
            <p> Cores que atraem o mosquito 
                https://www.uol.com.br/tilt/noticias/redacao/2024/04/27/roupa-vermelha-atrai-mosquito-da-dengue-por-que-cor-pode-facilitar-picada.htm </p>
            <p> extração de dados da revista fapesp dos últimos 2 anos sobre a dengue</p>
            <p>
            baixas plaquetas
            https://www.cnnbrasil.com.br/saude/o-que-sao-plaquetas-indicadores-de-gravidade-da-dengue/
            </p>
            <p>
            pulseira anti-dengue:
            https://beneblu.com/wp-content/uploads/2024/04/video-gif01-final.mp4 
            https://mrwisebuyer.com/advertorial-repel-band-ultra/?utm_source=taboola&utm_medium=cpc&utm_content=Bracelete+anti-dengue+bate+recordes+de+vendas+com+alta+hist%C3%B3rica+de+casos&utm_campaign=Repel+Band+Ultra+BR+Desktop+V1.0&utm_term=Bracelete+anti-dengue+bate+recordes+de+vendas+com+alta+hist%C3%B3rica+de+casos&ad_id=3940895759&utm_id=38139131&site_id=1154563&placement=caras&device=Desktop&thumbnail=http%3A%2F%2Fcdn.taboola.com%2Flibtrc%2Fstatic%2Fthumbnails%2F368fa2db84d527b9a74b682b83385e56.jpg&tblcid=GiBg6v5BfCGWjAyvfD8NgavrIyNiPOIU3b0fvycet2327iDY3mUo66_4rfuYgMpgMIO8Rg&tblci=GiBg6v5BfCGWjAyvfD8NgavrIyNiPOIU3b0fvycet2327iDY3mUo66_4rfuYgMpgMIO8Rg#tblciGiBg6v5BfCGWjAyvfD8NgavrIyNiPOIU3b0fvycet2327iDY3mUo66_4rfuYgMpgMIO8Rg
        </p>
        </ul>
</div>
@endsection