<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ubs', function (Blueprint $table) {
         
            $table->string('nome');
            $table->string('endereco');
            $table->string('bairro');
            $table->string('email');
            $table->string('telefone');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ubs', function (Blueprint $table) {
            $table->dropColumn(['nome', 'endereco', 'bairro', 'email', 'telefone']);
        });
    }
};
