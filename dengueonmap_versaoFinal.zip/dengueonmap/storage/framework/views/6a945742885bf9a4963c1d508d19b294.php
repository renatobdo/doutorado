 

<?php $__env->startSection('content'); ?>
    <h1>Detalhes do Produto</h1>
    <p>Produto: <?php echo e($produto); ?></p>
</div>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\produtos\show.blade.php ENDPATH**/ ?>