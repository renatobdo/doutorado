
<?php $__env->startSection('title',$event->titulo); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-10 offset-md-1">
        <div class="row">
            <div id="image-container" class="col-md-6">
                <img src="/img/events/<?php echo e($event->image); ?>" class="img-fluid" 
                    alt="<?php echo e($event->titulo); ?>">
            </div>
            <div id="info-container" class="col-md-6">
                <h1><?php echo e($event->titulo); ?></h1>
                <p class="event-city">
                    <ion-icon name="location-outline"></ion-icon>
                    <?php echo e($event->cidade); ?>

                </p>
                <p class="event-participants">
                    <ion-icon name="people-outline"></ion-icon>
                    <?php echo e(count($event->users)); ?> participantes
                </p>
                <p class="event-owner">
                    <ion-icon name="star-outline"></ion-icon>
                    <?php echo e($eventOwner['name']); ?>

                </p>                
                <!--<a href="#" class="btn btn-primary" id="event-submit">
                    confirmar presença</a> -->
                <?php if(!$hasUserJoined): ?>
                    <form action="/events/join/<?php echo e($event->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                        <a href= "/events/join/<?php echo e($event->id); ?>"
                            class="btn btn-primary"
                            id="event-submit"
                            onclick="event.preventDefault();
                            this.closest('form').submit();"> confirmar presença
                        </a>
                    </form>
                <?php else: ?>
                    <p class="already-joined-message">
                            Você já está participando desse evento!</p>
                <?php endif; ?>


                

                <!-- <h3>Sobre o evento: </h3>
                <ul id="items-list">
                
                </ul> -->
            </div>
            <div class="col-md-12" id="description-container">
                <h3>Sobre o evento</h3>
                <p class="event-descritpion"><?php echo e($event->descricao); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views/events/show.blade.php ENDPATH**/ ?>