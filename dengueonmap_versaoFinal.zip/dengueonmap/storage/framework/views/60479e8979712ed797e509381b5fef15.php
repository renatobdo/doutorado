<div>
    <!-- Well begun is half done. - Aristotle -->
</div>
<?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\almocos\show.blade.php ENDPATH**/ ?>