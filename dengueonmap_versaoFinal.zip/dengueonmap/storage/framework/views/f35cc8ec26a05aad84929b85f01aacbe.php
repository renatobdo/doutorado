

<?php $__env->startSection('title', $foco->nome_foco); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-10 offset-md-1">
        <div class="row">
            <div id="image-container" class="col-md-6">

                <img src="<?php echo e('../' . $foco->caminho_foto); ?>" alt="<?php echo e($foco->nome_foco); ?>" class="img-fluid">
            </div>
            <div id="info-container" class="col-md-6">
                <h1><?php echo e($foco->nome_foco); ?></h1>
                <p class="card-date"><?php echo e(date('d/m/Y', strtotime($foco->data_foco))); ?></p>
                <p class="card-text"><?php echo e($foco->descricao); ?></p>
                <p class="card-text">Identificado por: <?php echo e($focoOwner['name']); ?></p>

                
                    <?php if($hasUserIdentified): ?>
                        <p>Você identificou este foco.</p>
                    <?php else: ?>
                        <form action="<?php echo e(route('focos.join', ['id' => $foco->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary">Monitorar foco</button>
                        </form>
                    <?php endif; ?>
               
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\focos\show.blade.php ENDPATH**/ ?>