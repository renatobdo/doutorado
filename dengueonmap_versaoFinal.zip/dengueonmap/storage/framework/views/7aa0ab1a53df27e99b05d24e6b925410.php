

<?php $__env->startSection('title', 'Editar focos: '.$foco->nome_foco); ?>

<?php $__env->startSection('content'); ?>
<div id="foco-create-container" class="col-md-6 offset-md-3">
    <h1>Editando: <?php echo e($foco->nome_foco); ?></h1>
    <form id="focoForm" action="/focos/update/<?php echo e($foco->id); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="image">Imagem do foco:</label>
            <input type="file" id="image" name="image" class="form-control-file">
            <img src="/<?php echo e($foco->caminho_foto); ?>" alt="<?php echo e($foco->nome_foco); ?>" class="img-preview">
        </div>
        <div class="form-group">
            <label for="title">Nome do Foco:</label>
            <input type="text" class="form-control" id="nome_foco" name="nome_foco" placeholder="Nome do foco" value="<?php echo e($foco->nome_foco); ?>">
        </div>
        <div class="form-group">
            <label for="date">Data do Foco:</label>
            <input type="date" class="form-control" id="date" name="date" value="<?php echo e(date('Y-m-d', strtotime($foco->data_foco))); ?>">
        </div>
        <div class="form-group">
            <label for="cidade">Cidade:</label>
            <input type="text" class="form-control" id="cidade" name="cidade" placeholder="Local do foco" value="<?php echo e($foco->cidade); ?>">
        </div>
        <div class="form-group">
            <label for="descricao">Descrição do Foco:</label>
            <textarea id="descricao" name="descricao" class="form-control" placeholder="Descrição do foco"><?php echo e($foco->descricao); ?></textarea>
        </div>
        <br>
        <div class="form-group">
            <label for="focos_identificados">Adicione focos identificados</label>
            <?php
                $items = json_decode($foco->items, true) ?? [];
            ?>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Pneu" <?php echo e(in_array('Pneu', $items) ? 'checked' : ''); ?>>Pneu
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Vaso" <?php echo e(in_array('Vaso', $items) ? 'checked' : ''); ?>>Vaso de planta
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Garrafa" <?php echo e(in_array('Garrafa', $items) ? 'checked' : ''); ?>>Garrafa
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Plástico" <?php echo e(in_array('Plástico', $items) ? 'checked' : ''); ?>>Plástico
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Caixa d'água" <?php echo e(in_array("Caixa d'água", $items) ? 'checked' : ''); ?>>Caixa d'água
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Outros" <?php echo e(in_array('Outros', $items) ? 'checked' : ''); ?>>Outros
            </div>
        </div>
        <input type="submit" class="btn btn-primary" value="Editar Foco">
        <br><br>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\focos\edit.blade.php ENDPATH**/ ?>