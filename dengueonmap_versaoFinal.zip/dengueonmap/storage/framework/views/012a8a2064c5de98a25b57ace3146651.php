<?php $__env->startSection('title', 'Dashboard de Focos'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-10 offset-md-1 dashboard-title-container"><h1>Meus Focos</h1></div>
<div class="col-md-10 offset-md-1 dashboard-events-container">
    <?php if(count($focosIdentificados) > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>
           <?php $__currentLoopData = $focosIdentificados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
               <td scope="row"><?php echo e($loop->index + 1); ?></td>
               <td><a href="/focos/<?php echo e($foco->id); ?>"><?php echo e($foco->nome_foco); ?></a></td>
               <td>
                    <a href="/focos/edit/<?php echo e($foco->id); ?>" class="btn btn-info edit-btn">
                        <ion-icon name="create-outline"></ion-icon>Editar
                    </a>
                    <form action="/focos/<?php echo e($foco->id); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger delete-btn">
                            <ion-icon name="trash-outline"></ion-icon>Deletar
                        </button>
                    </form>
                </td>
           </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
    </table>
    <?php else: ?>
    <p>Você ainda não identificou nenhum foco, <a href="/focos/create">identificar foco</a></p>
    <?php endif; ?>
</div>
<div class="col-md-10 offset-md-1 dashboard-title-container"><h1>Focos que estou monitorando</h1></div>
<div class="col-md-10 offset-md-1 dashboard-events-container">
    <?php if(count($focosMonitorados) > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>
           <?php $__currentLoopData = $focosMonitorados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
               <td scope="row"><?php echo e($loop->index + 1); ?></td>
               <td><a href="/focos/<?php echo e($foco->id); ?>"><?php echo e($foco->nome_foco); ?></a></td>
               <td>
                    <form action="/focos/unmonitor/<?php echo e($foco->id); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger delete-btn">
                            <ion-icon name="trash-outline"></ion-icon>Deixar de Monitorar
                        </button>
                    </form>
                </td>
           </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
    </table>
    <?php else: ?>
    <p>Você ainda não está monitorando nenhum foco, <a href="/">veja todos os focos</a></p>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\focos\dashboard.blade.php ENDPATH**/ ?>