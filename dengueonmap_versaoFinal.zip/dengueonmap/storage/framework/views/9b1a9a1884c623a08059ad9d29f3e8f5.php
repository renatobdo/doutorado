<?php $__env->startSection('title', 'IFSP Eventos'); ?>

<?php $__env->startSection('content'); ?>

        <h1>Eventos IFSP</h1>
        <img src="img/logo-ifsp-removebg.png" alt="Banner">
            <?php if(10 > 5): ?>
                <p>A condição é true</p>
            <?php endif; ?>
        <?php echo e($nome); ?>

        <?php if($nome == 'Renato'): ?>
        <!-- o nome da variável é a chave -->
        
            <p>O nome é Renato e ele tem <?php echo e($idade); ?> anos e ele trabalha como <?php echo e($profissao); ?></p>
        <?php else: ?>
            <p>O nome não é Renato</p>
            
        <?php endif; ?>

        <?php for($i = 0; $i < count($arr); $i++): ?>
            <p><?php echo e($arr[$i]); ?> - <?php echo e($i); ?></p>
            <?php if($i == 2): ?>
                <p>O i é 2</p>
            <?php endif; ?>
        <?php endfor; ?>

        <?php
            $nome = "Testes<br>";
            echo $nome;
        ?>

        <?php $__currentLoopData = $nomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($loop->index); ?>

            <p><?php echo e($nome); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\welcome.blade.php ENDPATH**/ ?>