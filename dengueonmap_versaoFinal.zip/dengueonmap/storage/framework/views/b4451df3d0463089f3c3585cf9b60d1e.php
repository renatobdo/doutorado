<!DOCTYPE html>
<html>
<head>
    <title>Produtos</title>
    
</head>
<body>
    <h1>Lista de Produtos</h1>
    <ul>
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($produto); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\produtos.blade.php ENDPATH**/ ?>