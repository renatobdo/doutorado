<header>
    <nav class="navbar navbar-expand-md ">
        <div class="container-fluid">
            <a href="/" class="navbar-brand">
                <!--<img src="/img/logo-ifsp-removebg.png" alt="ifsp eventos" class="header-image ml-0">-->
               <!-- <img src="/img/eventosUsp.png" alt="ifsp eventos" class="header-image ml-0"> -->
               
                <!--<img src="/img/logo-ifsp-removebg.png" alt="ifsp eventos" class="header-image ml-0">-->
                <img src="/img/DengueOnMapLogo5.png" alt="ifsp eventos" class="header-image ml-0">
                
            
            </a>
            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse navbar-nav" id="navbar">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a href="/" class="nav-link mx-2">Focos da dengue</a>
                    </li>
                    <li class="nav-item">
                        <a href="/focos/identificarFoco" class="nav-link mx-2">Identificar foco</a>
                    </li>
                    <li class="nav-item">
                        <a href="/events/create" class="nav-link mx-2">Criar evento</a>
                    </li>
                    <li class="nav-item">
                        <a href="/catalogo" class="nav-link mx-2">Catálogo de dados</a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item">
                        <a href="/dashboard" class="nav-link mx-2">Editar</a>
                        <ul class="submenu">
                            <li><a href="/focos/dashboard">Meus focos</a></li>
                            <li><a href="/dashboard">Meus eventos</a></li>                            
                            
                            
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a href="/gestao" class="nav-link mx-2">Gerir dados</a>
                        <ul class="submenu">
                            <li><a href="/metricaseindicadores">Métricas e indicadores</a></li>
                            <li><a href="/repositorios">Repositórios</a></li>                            
                            <li><a href="/ml">Automatização</a></li>
                            <li><a href="/gis">GIS</a></li>
                            <li><a href="/campanhas">Campanhas</a></li>
                           
                            <li><a href="/tf">Trabalhos Futuros</a></li>
                            
                        </ul>
                    </li>
                    <li class="nav-item">
                        <form action="/logout" method="POST">
                        <?php echo csrf_field(); ?>
                        <a href="/logout" class="nav-link"
                            onclick="event.preventDefault();
                            this.closest('form').submit();">
                            Sair
                        </a>
                        </form>
                    </li>
                    <?php endif; ?>
                    
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a href="/login" class="nav-link mx-2">Entrar</a>
                    </li>
                    <li class="nav-item">
                        <a href="/register" class="nav-link mx-2">Cadastrar</a>
                    </li>
                    <?php endif; ?>
                   
                </ul>
            </div>
            
        </div>
    </nav>
    <head>
        <!-- Inclua o CSS do Leaflet.js -->
        <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
      
        <!-- Inclua o JavaScript do Leaflet.js -->
        <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
      </head>
      
</header><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views/layouts/header.blade.php ENDPATH**/ ?>