<div>
    <!-- Simplicity is the ultimate sophistication. - Leonardo da Vinci -->
</div>
<?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\almocos\index.blade.php ENDPATH**/ ?>