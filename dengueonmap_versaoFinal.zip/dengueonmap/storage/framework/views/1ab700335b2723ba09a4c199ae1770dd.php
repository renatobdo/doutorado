<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Bem-vindo</title>
</head>
<body>
    <h1>Paz no Oriente Médio!</h1>
    <?php echo e($message); ?>

    <?php if($usuario): ?>
        <h1>Usuário logado!</h1>
    <?php else: ?>
        <h1>Usuário não logado!</h1>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\paz.blade.php ENDPATH**/ ?>