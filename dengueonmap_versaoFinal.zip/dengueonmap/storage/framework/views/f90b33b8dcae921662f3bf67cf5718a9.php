


<?php $__env->startSection('title', 'Página de Repositórios sobre arboviroses'); ?>

<?php $__env->startSection('content'); ?>


<div id="search-container" class="clearfix">
    <h1>Página de repositórios sobre arboviroses</h1>
      
    <a href="https://ifrs.edu.br/veranopolis/biblioteca/recursos-de-acesso-aberto/repositorios-institucionais-e-tematicos/">
        Clique aqui para ler sobre repositórios institucionais e temáticos</a><br>
        <a href="https://github.com/renatobdo/catalogo-arboviroses/tree/main">
            Clique aqui para ver repositório de dados sobre arboviroses</a>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\repositorios.blade.php ENDPATH**/ ?>