

<?php $__env->startSection('title','Identificar focos'); ?>

<?php $__env->startSection('content'); ?>
<div id="event-create-container" class="col-md-6 offset-md-3">
    <h1>Identificação de focos de dengue</h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <form id="eventoForm" action="/focos" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">    
            <div class="custom-file">
                <label for="image">Imagem do foco:</label>
                <input type="file" id="image" name="image" class="custom-file-input">
            </div>
        </div>
        <div class="form-group">
            <label for="title">Nome do Foco:</label>
            <input type="text" class="form-control" id="title" name="title" placeholder="Dê um nome ao foco">
        </div>
        <div class="form-group">
            <label for="date">Data:</label>
            <input type="date" class="form-control" id="date" name="date" placeholder="Data do foco">
        </div>
        
        <div class="form-group">
            <label for="cep">CEP</label>
            <input type="text" class="form-control" id="cep" name="cep" placeholder="01234567 sem traço" oninput="validateCEP(this)">
            <a href="https://buscacepinter.correios.com.br/app/endereco/index.php?t" class="btn btn-link" target="_blank">Não sei o CEP</a>
        </div>
        <div class="form-group">
            <label for="city">Cidade:</label>
            <input type="text" class="form-control" id="city" name="city" placeholder="cidade">
        </div>
        <div class="form-group">
            <label for="state">Estado:</label>
            <input type="text" class="form-control" id="state" name="state" placeholder="estado">
        </div>
        <div class="form-group">
            <label for="endereco">Endereço</label>
            <input type="text" class="form-control" id="endereco" name="endereco" placeholder="Endereço">
        </div>
       
        <div class="form-group">
            <label for="description">Descrição do foco:</label>
            <textarea id="description" name="description" class="form-control custom-textarea" placeholder="Descrição do foco"></textarea>
        </div>
        <div class="form-group">
            <label for="focos_identificados">Selecione os focos que você identificou na imagem:</label>
        </div>
        <div class="form-group custom-border p-3">
            <div class="form-group">
                <input type="checkbox" name="items[]" value="pneu">Pneu
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Vaso">Vaso de planta
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Garrafa">Garrafa
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Plastico">Plástico
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="caixadagua">Caixa d'água
            </div>
            <div class="form-group">
                <input type="checkbox" name="items[]" value="Outros">Outros
            </div>
        </div>
        <input type="submit" class="btn btn-primary btn-IdentFoco" name="criar_evento" value="Enviar">
    </form>
</div>

<script>
    function validateCEP(input) {
        input.value = input.value.replace(/[^a-zA-Z0-9]/g, '');
    }
    
    const cepInput = document.getElementById('cep');
    const enderecoInput = document.getElementById('endereco');
    const cityInput = document.getElementById('city');
    const stateInput = document.getElementById('state');
    
    cepInput.addEventListener('change', function() {
        const cep = cepInput.value;
        
        fetch(`/buscarCep/${cep}`)
        .then(response => response.json())
        .then(data => {
            enderecoInput.value = data.logradouro;
            cityInput.value = data.localidade;
            stateInput.value = data.uf;
        })
        .catch(error => {
            console.error('Erro ao buscar CEP:', error);
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\events\teste.blade.php ENDPATH**/ ?>