


<?php $__env->startSection('title', 'Página de Métricas e indicadores sobre arboviroses'); ?>

<?php $__env->startSection('content'); ?>


<div id="search-container" class="clearfix">
    <h1>Página de Métricas e indicadores sobre arboviroses</h1>
      
    <a href="https://force11.org/info/the-fair-data-principles">
        Clique aqui para ler os Princípios FAIR</a><br>
        <a href="https://blog.dsacademy.com.br/as-6-dimensoes-da-qualidade-de-dados-data-quality/">
            Clique aqui para ler sobre as dimensões da qualidade de dados</a>

    <p>Probabilidade de se contrair a dengue em determinado local? (Sugestão da professora Fátima)</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\metricaseindicadores.blade.php ENDPATH**/ ?>