

<?php $__env->startSection('title','Editar eventos: '.$event->titulo); ?>

<?php $__env->startSection('content'); ?>
<div id="event-create-container" class="col-md-6 offset-md-3">
    <h1>Editando: <?php echo e($event->titulo); ?></h1>
    <form id="eventoForm" action="/events/update/<?php echo e($event->id); ?>" method="POST" 
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="image">Imagem do evento:</label>
            <input type="file" id="image" name="image" class="form-control-file">
            <img src="/img/events/<?php echo e($event->image); ?>" alt="<?php echo e($event->titulo); ?>" 
            class="img-preview">
        </div>
        <div class="form-group">
            <label for="title">Evento:</label>
            <input type="text" class="form-control" id="titulo" name="titulo" 
                placeholder="Nome do evento" value="<?php echo e($event->titulo); ?>">
        </div>
        <div class="form-group">
            <label for="date">Data do Evento:</label>
            <input type="date" class="form-control" id="date" name="date" 
                    value="<?php echo e(date('Y-m-d',strtotime($event->date))); ?>">
        </div>
        <div class="form-group">
            <label for="title">Cidade:</label>
            <input type="text" class="form-control" id="cidade" name="cidade" 
            placeholder="Local do evento" value="<?php echo e($event->cidade); ?>">
        </div>
       
        <div class="form-group">
            <label for="title">Descrição do evento:</label>
            <textarea id="descricao" name="descricao" class="form-control" 
            placeholder="Descrição do evento"><?php echo e($event->descricao); ?></textarea>
        </div>
        <br>
       
        <input type="submit" class="btn btn-primary" 
        value="editar evento">

        <br><br>

    </form>
   </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views/events/edit.blade.php ENDPATH**/ ?>