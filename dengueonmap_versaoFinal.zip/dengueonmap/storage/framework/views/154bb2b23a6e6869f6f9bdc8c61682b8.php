<h1>Esta é a página de contato</h1>
<a href="/">Voltar para home</a><?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\contact.blade.php ENDPATH**/ ?>