<!DOCTYPE html>
<html>
     <!--a seção yield será preenchida com o conteúdo específico da view. -->
<head>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <header>
        <!-- Cabeçalho do site -->
    </header>

    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer>
        <!-- Rodapé do site -->
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\dengueonmap\resources\views\layout.blade.php ENDPATH**/ ?>