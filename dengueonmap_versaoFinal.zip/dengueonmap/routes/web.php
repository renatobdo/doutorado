<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EventController;
use App\Http\Controllers\CoordinateController;
use App\Http\Controllers\FocoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Rota principal
Route::get('/', [EventController::class, 'index']);
Route::post('/events', [EventController::class, 'store']);
Route::get('/events/create', [EventController::class, 'create'])->middleware('auth');
Route::get('/events/{id}', [EventController::class, 'show'])->middleware('auth');
Route::delete('/events/{id}', [EventController::class, 'destroy'])->middleware('auth');
Route::get('/events/edit/{id}', [EventController::class, 'edit'])->middleware('auth');
Route::put('/events/update/{id}', [EventController::class, 'update'])->middleware('auth');
Route::post('/events/join/{id}', [EventController::class, 'joinEvent'])->middleware('auth');
Route::delete('/events/leave/{id}', [EventController::class, 'leaveEvent'])->middleware('auth');

// Rotas para focos
Route::post('/focos', [FocoController::class, 'store']);
Route::get('/focos/identificarFoco', [FocoController::class, 'identificarFoco'])->middleware('auth');
Route::get('/focos/identificarFoco/{id}', [FocoController::class, 'edit'])->middleware('auth');
Route::get('/focos/edit/{id}', [FocoController::class, 'edit'])->middleware('auth');
Route::delete('/focos/{id}', [FocoController::class, 'destroy'])->middleware('auth');
Route::put('/focos/update/{id}', [FocoController::class, 'update'])->middleware('auth');
Route::get('/focos/dashboard', [FocoController::class, 'dashboard'])->middleware('auth')->name('focos.dashboard');;
Route::post('/focos/join/{id}', [FocoController::class, 'joinFoco'])->middleware('auth')->name('focos.join');
Route::delete('/focos/unmonitor/{id}', [FocoController::class, 'unmonitorFoco'])->middleware('auth')->name('focos.unmonitor');
Route::get('/focos/{id}', [FocoController::class, 'show'])->middleware('auth')->name('focos.show');


// Rota para buscar focos próximos
Route::get('/buscarFocosProximos', [EventController::class, 'buscarFocosProximos']);

// Rota para buscar CEP
Route::get('/buscarCep/{cep}', [CoordinateController::class, 'buscarCep']);
Route::get('/buscarDengue/{cep}', [EventController::class, 'buscarCasosDengue']);

// Outras rotas
Route::get('/metricaseindicadores', function () {
    return view('metricaseindicadores');
});
Route::get('/repositorios', function () {
    return view('repositorios');
});
Route::get('/gestao', function () {
    return view('gestao');
});
Route::get('/tf', function () {
    return view('tf');
});
Route::get('/campanhas', function () {
    return view('campanhas');
});

Route::get('catalogo', [EventController::class, 'showCatalogo']);
Route::get('dashboard', [EventController::class, 'dashboard'])->middleware('auth');
Route::get('/contact', function () {
    return view('contact');
});
Route::get('/produtos', function () {
    return view('products');
});
Route::get('/jogo', function () {
    return view('jogo');
});

Route::get('/paz', function () {
    $messages = [
        "paz no Oriente Médio",
        "A paz é a única forma de nos sentirmos realmente humanos",
        "Não existe um caminho para a paz. A paz é o caminho"
    ];
    $isUserLoggedIn = false;
    $randomMessage = $messages[array_rand($messages)];
    return view('paz', [
        'message' => $randomMessage,
        'usuario' => $isUserLoggedIn
    ]);
});

Route::post('/cadastro', 'CadastroController@submitForm');

Route::get('/teste', function () {
    $nome = "Renato";
    $idade = 20;
    $arr = [1, 2, 3, 4, 5];
    $nomes = ["Renato", "Paula", "Laura", "Helena"];

    return view('welcome', [
        'nome' => $nome,
        'idade' => $idade,
        'profissao' => 'professor',
        'arr' => $arr,
        'nomes' => $nomes
    ]);
});
Route::get('/teste', function () {
    return view('events.teste');
});
Route::get('/produtos/{id}', function ($id) {
    return view('layouts.product', ['id' => $id]);
});
Route::get('/produtos_teste/{id?}', function ($id = null) {
    return view('layouts.product', ['id' => $id]);
});
Route::get('/produtos', function () {
    $busca = request('search');
    return view('products', ['busca' => $busca]);
});

Route::get('/inicio', [EventController::class, 'index']);
